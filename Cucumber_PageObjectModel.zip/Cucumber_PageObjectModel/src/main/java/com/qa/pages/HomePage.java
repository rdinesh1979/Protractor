package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class HomePage extends TestBase {
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//span[@class='user-display']")
	private WebElement homePageUserNameDisplay;

	
	@FindBy(xpath="//span[contains(text(),'Home')]")
	private WebElement homeLink;
	
	@FindBy(xpath="//span[contains(text(),'Calendar')]")
	private WebElement calendarLink;
	
	@FindBy(xpath="//span[contains(text(),'Contacts')]")
	private WebElement contactsLink;
	
	
	@FindBy(xpath="//span[contains(text(),'Companies')]")
	private WebElement companiesLink;
	
	@FindBy(xpath="//span[contains(text(),'Deals')]")
	private WebElement dealsLink;
	
	@FindBy(xpath="//span[contains(text(),'Tasks')]")
	private WebElement tasksLink;
	
	@FindBy(xpath="//span[contains(text(),'Cases')]")
	private WebElement casesLink;
	
	@FindBy(xpath="//span[contains(text(),'Calls')]")
	private WebElement callsLink;
	
	@FindBy(xpath="//span[contains(text(),'Documents')]")
	private WebElement documentsLink;
	
	@FindBy(xpath="//span[contains(text(),'Email')]")
	private WebElement emailLink;
	
	@FindBy(xpath="//span[contains(text(),'Campaigns')]")
	private WebElement campaignsLink;
	
	
	
	//actions in the page:
	
	public WebElement getHomePageUserNameDisplay() {
		return homePageUserNameDisplay;
	}

	public WebElement getHomeLink() {
		return homeLink;
	}

	public WebElement getCalendarLink() {
		return calendarLink;
	}

	public WebElement getContactsLink() {
		return contactsLink;
	}

	public WebElement getCompaniesLink() {
		return companiesLink;
	}

	public WebElement getDealsLink() {
		return dealsLink;
	}

	public WebElement getTasksLink() {
		return tasksLink;
	}

	public WebElement getCasesLink() {
		return casesLink;
	}

	public WebElement getCallsLink() {
		return callsLink;
	}

	public WebElement getDocumentsLink() {
		return documentsLink;
	}

	public WebElement getEmailLink() {
		return emailLink;
	}

	public WebElement getCampaignsLink() {
		return campaignsLink;
	}

	public String verifyHomePageTitle() {
	    return driver.getTitle();
	}
	
	public boolean verifyCorrectUserName() {
		return getHomePageUserNameDisplay().isDisplayed();
	}
	
	public void clickOnHomeLink() {
		getHomeLink().click();
	}
	
	public void clickOnCalendarLink() {
		 getCalendarLink().click();
	}
	
	public void clickOnContactsLink()  {
		 getContactsLink().click();
	}
	
	public void clickOnCompaniesLink()  {
		getCompaniesLink().click();
	}
	
	public void clickOnDealsLink()  {
	   getDealsLink().click();
	}
	
	public void clickOnTasksLink()  {
		   getTasksLink().click();
	}
	
	public void clickOnCasesLink()  {
		   getCasesLink().click();
	}
	
	public void clickOnCallsLink()  {
		   getCallsLink().click();
	}
	public void clickOnDocumentsLink()  {
		   getDocumentsLink().click();
	}
	public void clickOnEmailLink()  {
		   getEmailLink().click();
	}
	public void clickOnCampaignsLink()  {
		   getCampaignsLink().click();
	}
}
