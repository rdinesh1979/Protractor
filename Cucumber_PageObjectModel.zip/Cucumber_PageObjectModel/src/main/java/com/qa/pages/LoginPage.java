package com.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class LoginPage extends TestBase{

	@FindBy(xpath="//a[@href='https://ui.freecrm.com']/span[2]")
	private WebElement loginLink;
	
	@FindBy(name="email")
	private WebElement username;
	
	@FindBy(name="password")
	private  WebElement password;
	
	@FindBy(xpath="//*[@id='ui']/div/div/form/div/div[3]")
	private WebElement loginButton;
	
	@FindBy(xpath="//a[@href='https://api.cogmento.com/register']")
	private WebElement signUpLink;

	public WebElement getSignUpLink() {
		return signUpLink;
	}

	public WebElement getLoginLink() {
		return loginLink;
	}

	public WebElement getUsername() {
		return username;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}
	
	
	
	// Initializing the Page Objects
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	// Actions Performed in Login Page
	
	public String validateLoginPageTitle() {
		return driver.getTitle();
	}
	
	public boolean verifySignUpLink() {
		
		return getSignUpLink().isDisplayed();
		
	}
	
	
	public HomePage loginPage(String un, String pwd)
	{
		getUsername().sendKeys(un);
		getPassword().sendKeys(pwd);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", getLoginButton());
		return new HomePage();
	}
}
