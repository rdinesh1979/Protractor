package com.qa.util;

public class TestUtil {
	
	static int PAGE_LOAD_TIMEOUT=80;
	static int IMPLICIT_WAIT=40;

}
