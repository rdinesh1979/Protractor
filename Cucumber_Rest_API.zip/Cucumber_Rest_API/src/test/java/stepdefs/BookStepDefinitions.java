package stepdefs;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class BookStepDefinitions {

	private Response response;
	private ValidatableResponse json;
	private RequestSpecification request;
	public ExtentReports extent;
	public ExtentTest	test;
	
	@Given("^initialize the test report$")
	public void initialize_the_test_report() {
	
		 extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/APIExtentReport.html");
		 extent
	    .addSystemInfo("Host Name", "Localhost")
	    .addSystemInfo("Environment", "QA")
	    .addSystemInfo("User Name", "Dinesh");
	     extent.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));
	}
	 
	private String ENDPOINT_GET_BOOK_BY_ISBN = "https://www.googleapis.com/books/v1/volumes";
	

	@Given("a book exists with an isbn of (.*)")
	public void a_book_exists_with_isbn(String isbn){
		test = extent.startTest("API Application Test");
		request = given().param("q", "isbn:" + isbn);
		test.log(LogStatus.INFO, "Trying to retrieve a book with isbn number: "+isbn);
	}

	@When("a user retrieves the book by isbn")
	public void a_user_retrieves_the_book_by_isbn(){
		response = request.when().get(ENDPOINT_GET_BOOK_BY_ISBN);
		System.out.println("response: " + response.prettyPrint());
		test.log(LogStatus.PASS, "Successfully retrieved the book by its isbn nuumber");
	}

	@Then("the status code is (\\d+)")
	public void verify_status_code(int statusCode){
		json = response.then().statusCode(statusCode);
		System.out.println(json);
		test.log(LogStatus.PASS, "Successfully Verified the Status code as 200 OK");
	}

	@And("response includes the following$")
	public void response_equals(Map<String,String> responseFields){
		for (Map.Entry<String, String> field : responseFields.entrySet()) {
			if(StringUtils.isNumeric(field.getValue())){
				json.body(field.getKey(), equalTo(Integer.parseInt(field.getValue())));
				test.log(LogStatus.PASS, "Successfully verified the Total Items of the book: "+field.getValue());
			}
			else{
				json.body(field.getKey(), equalTo(field.getValue()));
				test.log(LogStatus.PASS, "Successfully verified the Kind of the Book: "+field.getValue());
			}
		}
	}

	@And("response includes the following in any order")
	public void response_contains_in_any_order(Map<String,String> responseFields){
		for (Map.Entry<String, String> field : responseFields.entrySet()) {
			if(StringUtils.isNumeric(field.getValue())){
				json.body(field.getKey(), containsInAnyOrder(Integer.parseInt(field.getValue())));
				test.log(LogStatus.PASS, "Successfully verified the Page Count: "+field.getValue());
				
			}
			else{
				json.body(field.getKey(), containsInAnyOrder(field.getValue()));
				test.log(LogStatus.PASS, "Successfully verified the Title and Publisher: "+field.getValue());
			}
		}
	}
	
	@Then("^generate report$")
	public void generate_report() throws Throwable{
		if(extent != null) {
		   extent.endTest(test);
		   extent.flush();
		}
}

}
