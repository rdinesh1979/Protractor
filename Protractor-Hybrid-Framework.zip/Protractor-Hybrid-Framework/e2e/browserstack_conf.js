exports.config = {
   // directConnect : true,
    /**
     * If true, Protractor will connect directly to the browser Drivers.
     * Only chrome and Firefox are supported for direct connect.
     * default: false
     */
    framework: 'jasmine2',
    allScriptTimeout: 60000, //1 Min
   
    jasmineNodeOpts:{
        showColors: true, //In you terminal it will show the colors
        defaultTimoutInterval: 60000,
    },
    'seleniumAddress' : 'http://hub-cloud.browserstack.com/wd/hub',
    'capabilities' : {
        'browserstack.user':'dineshr3',
        'browserstack.key' : 'vmsHHMGGppAK9ydFteV4',
        'device' : 'iPhone XS',
        'realMobile': 'true',
        'os_version'  : '12',
        'browserName' : 'Chrome',
        'browserstack.debug' :'true',
        
    },
    onPrepare: function(){
        //browser.driver.manage().window().maximize();
        browser.driver.get('https://angular.io/events');
    
    },
    suites :{
       sampleTestCase : 'tests/smoke/sampleTestCase.spec.js',
      //smoke : ['tests/smoke/sampleTestCase.spec.js',],

      //regression : ['tests/regression/sampleTestCase.spec.js']
    }

}