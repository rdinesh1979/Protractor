var xcelToJson = require('./xcelToJson');

//QA : protractor confjs --suite smoke/regression --parameters.url.qa
//QA : protractor confjs --suite smoke/regression --parameters.url.dev
//QA : protractor confjs --suite smoke/regression --parameters.url.stag
//QA : protractor confjs --suite smoke/regression --parameters.url.prod

exports.config = {
    directConnect : true,
    /**
     * If true, Protractor will connect directly to the browser Drivers.
     * Only chrome and Firefox are supported for direct connect.
     * default: false
     */
    framework: 'jasmine2',
    allScriptTimeout: 60000, //1 Min
    multiCapabilities:[
        {browserName : 'chrome'},
       // {browserName : 'firefox'},
    ],
    jasmineNodeOpts:{
        showColors: true, //In you terminal it will show the colors
        defaultTimoutInterval: 60000,
    },
    params: {
        url: {
            qa: xcelToJson.testConfig.applicationUrl_QA,
            dev: xcelToJson.testConfig.applicationUrl_Dev,
            prod: xcelToJson.testConfig.applicationUrl_Prod,
            stag: xcelToJson.testConfig.applicationUrl_Stagging,
        }
    },
    onPrepare: function(){
        browser.driver.manage().window().maximize();
        //browser.driver.get('https://angular.io/events');
        //browser.driver.get(xcelToJson.testConfig.applicationUrl_Dev);
       // console.log(xcelToJson.testConfig.applicationUrl_Dev);
       if (process.argv[5] != null) {
        var urlString = process.argv[5].substring(13);
        console.log("get the args::", urlString);
        if(urlString == "url.qa") {
            browser.driver.get(browser.params.url.qa);
        } else if (urlString == "url.dev") {
            browser.driver.get(browser.params.url.dev);
        } else if(urlString == "url.stag") {
            browser.driver.get(browser.params.url.stag);
        } else if(urlString == "url.prod") {
            browser.driver.get(browser.params.url.prod);
        }

       } else{
           browser.driver.get(browser.params.url.qa)
       }
    },
    
    suites :{
     //   sampleTestCase : 'tests/smoke/sampleTestCase.spec.js',
      smoke : ['tests/smoke/sampleTestCase.spec.js',],

      regression : ['tests/regression/sampleTestCase.spec.js']
    }

}