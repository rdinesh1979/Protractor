var xcelToJson = require('../../xcelToJson');
describe('REGRESSION SAMPLE TEST', ()=>{

    let times = 4;

    //for(let i=0; i<=times; i++){
        if(xcelToJson.smokeTest.test2 === "Yes") {
    it('execute sample test case: ASYNC-AWAIT', async()=>{  //Handling the Promise for getTitle, getURL and getAttribute
        browser.driver.manage().window().maximize();
        browser.driver.get('https://angular.io/events');
        const requiredTitle = await browser.driver.getTitle();
        console.log('TITLE:',requiredTitle);
        await expect(requiredTitle).toEqual('Angular - REGRESSION EVENTS');
    });
    }
 //  }    
});