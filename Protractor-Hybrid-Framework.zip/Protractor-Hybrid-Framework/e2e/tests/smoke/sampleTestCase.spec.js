var xcelToJson = require('../../xcelToJson');


async function documentCall(){
    return await document.querySelector('any css');
};

async function documentCallAll(){
    return await document.querySelectorAll('any css');
};

async function documentCallCookie(){
    return await document.cookie;
};

async function documentCallLocation(){
    return await document.location;
};

describe('SAMPLE TEST', ()=>{

    //let times = 4;

   // for(let i=0; i<=times; i++){
    if(xcelToJson.smokeTest.test1 === "Yes") {
    it('execute sample test case: ASYNC-AWAIT', async()=>{  //Handling the Promise for getTitle, getURL and getAttribute
        browser.driver.manage().window().maximize();
        browser.driver.get('https://angular.io/events');
        const requiredTitle = await browser.driver.getTitle();
        console.log('TITLE:', requiredTitle);
        await expect(requiredTitle).toEqual('Angular - EVENTS');

        const resDocumentCall = await browser.executeScript(documentCall);
        console.log('resDocumentCall::', resDocumentCall);
       // document.querySelector('any css'); // THIS WILL NOT WORK // document is undefined

       const resDocumentCallAll = await browser.executeScript(documentCallAll);
       console.log('resDocumentCallAll::', resDocumentCallAll);

       const resDocumentCallCookie = await browser.executeScript(documentCallCookie);
       console.log('resDocumentCallCookie::', resDocumentCallCookie);

       const resDocumentCallLocation = await browser.executeScript(documentCallLocation);
       console.log('resDocumentCallLocation::', resDocumentCallLocation);


    });
    }
   //}    
});